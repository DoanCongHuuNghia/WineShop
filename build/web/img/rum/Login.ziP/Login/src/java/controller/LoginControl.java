/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.Cookie;

/**
 *
 * @author ASUS
 */
public class LoginControl extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
              String user = request.getParameter("user");
      String pass = request.getParameter("password");
      String rememberMe = request.getParameter("rememberMe");

        try {
                    String Suser = request.getParameter("user");
        String Spass = request.getParameter("password");
        if( user.equals("administrator") && pass.equals("123") ){
HttpSession session = request.getSession();
        session.setAttribute("user", user);
        session.setAttribute("pass", pass);

        // Create cookies for "Remember Me" option
        if (rememberMe != null && rememberMe.equals("on")) {
//            session.setAttribute("tempuser", account.getUsername());
            Cookie cookieUser = new Cookie("user", user);
            cookieUser.setMaxAge(60*5); // Set the cookie to expire after 1 week
            response.addCookie(cookieUser);

            Cookie cookiePass = new Cookie("pass", pass);
            cookiePass.setMaxAge(60*5); // Set the cookie to expire after 1 week
            response.addCookie(cookiePass);
        }

        request.getRequestDispatcher("Detail.jsp").forward(request, response);

        }else
            request.getRequestDispatcher("login.jsp").forward(request, response);
        } catch (Exception e) {
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
   processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
